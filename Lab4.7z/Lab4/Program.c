#include <stdio.h>
#include <string.h>
void nhapMang(float a[], int n) {
    for (int i = 0; i < n; i++) {
        printf("Nhap diem SV thu %d: ", i + 1);
        scanf("%f", &a[i]);
    }
}

void xuatMang(float a[], int n) {
    for (int i = 0; i < n; i++)
        printf("%.2f  ", a[i]);
    printf("\n");
}

int demDiemTb(float a[], int n) {
    int dem = 0;
    for (int i = 0; i < n; i++)
        if (a[i] >= 5) dem++;
    return dem;
}

int viTriMax(float a[], int n) {
    int vt = 0;
    for (int i = 1; i < n; i++)
        if (a[i] > a[vt]) vt = i;
    return vt;
}

void bai3() {
    int n;
    float diem[100];

    printf("\nNhap so luong sinh vien: ");
    scanf("%d", &n);

    nhapMang(diem, n);

    printf("\nHien thi thong tin sinh vien\n");
    printf("So luong SV: %d\n", n);
    printf("Danh sach diem: ");
    xuatMang(diem, n);
    printf("So SV diem >= 5: %d\n", demDiemTb(diem, n));
    int vt = viTriMax(diem, n);
    printf("Vi tri diem cao nhat: %d (diem = %.2f)\n", vt + 1, diem[vt]);
}
void bai2() {
    int n, sum = 0;
    printf("\nNhap so nguyen duong n: ");
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        if (i % 2 != 0) {
            sum += i;
        }
    }
    printf("\nTong cac so le tu 1 den %d la: %d", n, sum);
}
void bai1() {
    char mon1[10], mamon1[10];
    int tinchi1, tienHoc;
    printf("\nNhap ten mon: ");
    fflush(stdin);
    scanf("%s", &mon1);
    printf("\nNhap ma mon: ");
    fflush(stdin);
	scanf("%s", &mamon1);
	printf("\nNhap so tin chi: ");
	scanf("%d", &tinchi1);
    printf("\n--- Thong tin vua nhap \n");
    printf("\nTen mon: %s", mon1);
	printf("\nMa mon: %s", mamon1);
	printf("\nSo tin chi: %d", tinchi1);
	tienHoc = tinchi1 * 500000;
	printf("\nTien hoc phai dong: %d VND", tienHoc);
}
int main() {
    int chon;
    do {
		printf("\nChon chuc nang\n");
        printf("1. Thong tin mon hoc\n");
        printf("2. tinh tong so le\n");
        printf("3. Thong tin diem Lab\n");
        printf("0. Thoat\n");

        printf("Moi chon: ");
        scanf("%d", &chon);

        switch (chon) {
        case 1: bai1(); break;
        case 2: bai2(); break;
        case 3: bai3(); break;
        case 0: printf("Thoat chuong trinh...\n"); break;
        default: printf("Lua chon khong hop le!\n");
        }
    } while (chon != 0);

    return 0;
}
